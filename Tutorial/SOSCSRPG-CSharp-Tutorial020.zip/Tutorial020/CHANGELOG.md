# Changelog

## [1.0.0] — Tutorial 020 release candidate

- Preserve Tutorial 019's UI-independent RPG engine and terminal adapter.
- Include 10 deterministic regression tests.
- Add GitHub Actions build, test, and portable Linux publish workflow.
- Add local verification and packaging scripts.
- Document known limitations and GitHub release process.

**Scope:** Educational terminal RPG. MonoGame + Myra, save/load, and external data-driven content are not included.
