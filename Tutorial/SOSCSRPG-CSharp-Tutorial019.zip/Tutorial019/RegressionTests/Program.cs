using RpgEngine;
int passed = 0, failed = 0;
void Test(string name, Action test)
{
    try { test(); Console.WriteLine($"PASS {name}"); passed++; }
    catch (Exception ex) { Console.WriteLine($"FAIL {name}: {ex.Message}"); failed++; }
}
void Assert(bool condition, string message) { if (!condition) throw new Exception(message); }
GameEngine NewGame() => new(new FixedRandomSource(99));
void Win(GameEngine game)
{
    var combat = game.BeginCombat() ?? throw new Exception("No encounter");
    for (int i = 0; i < 8 && !combat.Ended; i++) combat.Act("attack");
    Assert(combat.Ended && combat.EnemyHealth == 0, "Expected enemy defeat");
}
Test("Town starts with 30 HP", () => { var g = NewGame(); Assert(g.Location == "town" && g.Health == 30, "Incorrect initial state"); });
Test("Invalid route does not move", () => { var g = NewGame(); Assert(!g.Move("north") && g.Location == "town", "Invalid route accepted"); });
Test("World navigation connects hut and cave", () => { var g = NewGame(); Assert(g.Move("west") && g.Location == "hut", "Hut inaccessible"); Assert(g.Move("east") && g.Move("east") && g.Move("south") && g.Location == "cave", "Cave inaccessible"); });
Test("Quest must be accepted at hut", () => { var g = NewGame(); Assert(!g.QuestAccepted, "Quest initially accepted"); g.Move("west"); g.Talk(); Assert(g.QuestAccepted, "Quest not accepted"); });
Test("Guaranteed Spider Silk on every cave victory", () => { var g = NewGame(); g.Move("east"); g.Move("south"); for (int i = 1; i <= 3; i++) { Win(g); Assert(g.Count("Spider Silk") == i, "Silk count incorrect"); } });
Test("Quest completion consumes 3 silk and pays once", () => { var g = NewGame(); g.Move("west"); g.Talk(); g.Move("east"); g.Move("east"); g.Move("south"); for (int i = 0; i < 3; i++) Win(g); g.Move("north"); g.Move("west"); g.Move("west"); Assert(g.Location == "hut", "Wrong location"); g.Talk(); Assert(g.QuestCompleted && g.Count("Spider Silk") == 0 && g.Gold == 29, "Quest reward/consumption incorrect"); g.Talk(); Assert(g.Gold == 29, "Quest rewarded twice"); });
Test("Merchant requires sufficient funds and correct location", () => { var g = NewGame(); Assert(!g.BuyPotion(), "Bought outside shop"); g.Move("west"); g.Move("south"); Assert(!g.BuyPotion(), "Bought without gold"); });
Test("Invalid combat action consumes no turn", () => { var g = NewGame(); g.Move("east"); var fight = g.BeginCombat()!; int hp = g.Health; fight.Act("invalid"); Assert(g.Health == hp && fight.EnemyHealth == 9, "Invalid action changed state"); });
Test("Combat is unavailable in safe locations", () => { var g = NewGame(); Assert(g.BeginCombat() is null, "Combat available in town"); });
Test("Flee ends combat without loot", () => { var g = NewGame(); g.Move("east"); g.Move("south"); var fight = g.BeginCombat()!; fight.Act("flee"); Assert(fight.Ended && g.Count("Spider Silk") == 0 && g.Gold == 0, "Flee granted loot"); });
Console.WriteLine($"\nResults: {passed} passed, {failed} failed");
return failed == 0 ? 0 : 1;
