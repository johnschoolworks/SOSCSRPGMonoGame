namespace RpgEngine;

public interface IRandomSource { int Next(int minInclusive, int maxExclusive); }
public sealed class SystemRandomSource(int? seed = null) : IRandomSource
{
    private readonly Random _random = seed.HasValue ? new Random(seed.Value) : new Random();
    public int Next(int minInclusive, int maxExclusive) => _random.Next(minInclusive, maxExclusive);
}
public sealed class FixedRandomSource(int value = 99) : IRandomSource
{
    public int Next(int minInclusive, int maxExclusive) => minInclusive + (int)(Math.Abs((long)value) % (maxExclusive - minInclusive));
}
public sealed class GameEngine
{
    private readonly IRandomSource _random;
    private readonly Dictionary<string, Dictionary<string, string>> _exits = new(StringComparer.OrdinalIgnoreCase);
    private readonly Dictionary<string, int> _inventory = new(StringComparer.OrdinalIgnoreCase);
    public string Location { get; private set; } = "town";
    public int Health { get; private set; } = 30;
    public int Gold { get; private set; }
    public bool QuestAccepted { get; private set; }
    public bool QuestCompleted { get; private set; }
    public IReadOnlyDictionary<string, int> Inventory => _inventory;
    public GameEngine(IRandomSource? random = null)
    {
        _random = random ?? new SystemRandomSource();
        foreach (var place in new[] { "town", "hut", "forest", "cave", "post" })
            _exits[place] = new(StringComparer.OrdinalIgnoreCase);
        Link("town", "west", "hut", "east");
        Link("town", "east", "forest", "west");
        Link("hut", "south", "post", "north");
        Link("forest", "south", "cave", "north");
        Link("hut", "east", "forest", "west");
    }
    private void Link(string a, string directionA, string b, string directionB)
    { _exits[a][directionA] = b; _exits[b][directionB] = a; }
    public IReadOnlyCollection<string> AvailableExits => _exits[Location].Keys;
    public bool Move(string direction)
    {
        if (!_exits[Location].TryGetValue(direction, out var next)) return false;
        Location = next;
        return true;
    }
    public int Count(string item) => _inventory.GetValueOrDefault(item);
    private void Add(string item, int count) => _inventory[item] = Count(item) + count;
    private bool Remove(string item, int count)
    {
        if (count <= 0 || Count(item) < count) return false;
        int remainder = Count(item) - count;
        if (remainder == 0) _inventory.Remove(item); else _inventory[item] = remainder;
        return true;
    }
    public string Talk()
    {
        if (Location == "post") return "Merchant: Healing potions cost 5 gold.";
        if (Location != "hut") return "There is nobody here to talk to.";
        if (QuestCompleted) return "Alchemist: Thank you again for the silk!";
        if (!QuestAccepted) { QuestAccepted = true; return "Alchemist: Bring me 3 Spider Silk for 20 gold!"; }
        if (Count("Spider Silk") < 3) return $"Alchemist: You have {Count("Spider Silk")}/3 Spider Silk.";
        Remove("Spider Silk", 3);
        Gold += 20;
        QuestCompleted = true;
        return "Quest complete! You received 20 gold.";
    }
    public string QuestStatus => QuestCompleted ? "Spider Silk: Completed." : QuestAccepted ? $"Spider Silk: {Count("Spider Silk")}/3 collected." : "No active quests. Visit the Alchemist Hut.";
    public bool BuyPotion()
    {
        if (Location != "post" || Gold < 5) return false;
        Gold -= 5; Add("Potion", 1); return true;
    }
    public bool UsePotion()
    {
        if (Count("Potion") == 0) return false;
        Remove("Potion", 1); Health = Math.Min(30, Health + 12); return true;
    }
    public CombatSession? BeginCombat() => Location is "forest" or "cave" ? new CombatSession(this, Location == "cave") : null;
    public sealed class CombatSession
    {
        private readonly GameEngine _game;
        private readonly bool _spider;
        private bool _defending;
        public string EnemyName => _spider ? "Cave Spider" : "Forest Wolf";
        public int EnemyHealth { get; private set; }
        public bool Ended { get; private set; }
        internal CombatSession(GameEngine game, bool spider)
        { _game = game; _spider = spider; EnemyHealth = spider ? 12 : 9; }
        public string Act(string action)
        {
            if (Ended) return "Combat has already ended.";
            action = action.Trim().ToLowerInvariant();
            if (action == "flee") { Ended = true; return "You escape!"; }
            string message;
            switch (action)
            {
                case "attack":
                    if (_game._random.Next(0, 100) < 10) message = $"The {EnemyName} dodges!";
                    else
                    {
                        bool critical = _game._random.Next(0, 100) < 15;
                        int damage = _game._random.Next(4, 8) * (critical ? 2 : 1);
                        EnemyHealth = Math.Max(0, EnemyHealth - damage);
                        message = $"You deal {damage} damage{(critical ? " (CRITICAL!)" : "")}.";
                    }
                    break;
                case "defend": _defending = true; message = "You brace for the next attack."; break;
                case "potion":
                    if (!_game.UsePotion()) return "No potions available.";
                    message = "You drink a healing potion."; break;
                default: return "Choose attack, defend, potion, or flee.";
            }
            if (EnemyHealth == 0)
            {
                Ended = true;
                _game.Gold += _spider ? 3 : 2;
                if (_spider)
                {
                    _game.Add("Spider Silk", 1); // Guaranteed, never random.
                    message += " Loot: 1 Spider Silk (guaranteed), 3 gold.";
                    if (_game._random.Next(0, 100) < 25) { _game.Add("Potion", 1); message += " Bonus loot: 1 Potion!"; }
                }
                else message += " Loot: 2 gold.";
                return message + $" You defeated the {EnemyName}!";
            }
            int incoming = _game._random.Next(2, 6);
            if (_defending) incoming = (incoming + 1) / 2;
            _defending = false;
            _game.Health = Math.Max(0, _game.Health - incoming);
            message += $" The {EnemyName} hits you for {incoming} damage.";
            if (_game.Health == 0)
            {
                Ended = true;
                _game.Health = 30;
                _game.Location = "town";
                message += " You were defeated and recover at Town Square.";
            }
            return message;
        }
    }
}
