using RpgEngine;
var game = new GameEngine();
Console.WriteLine("SOSCSRPG Tutorial 019 — Type help for commands.");
GameEngine.CombatSession? combat = null;
while (true)
{
    Console.Write(combat is null ? "\n> " : $"[HP {game.Health}/30 | {combat.EnemyName} {combat.EnemyHealth}] action> ");
    var input = Console.ReadLine();
    if (input is null || input.Trim().Equals("quit", StringComparison.OrdinalIgnoreCase)) break;
    var parts = input.Trim().Split(' ', 2, StringSplitOptions.RemoveEmptyEntries);
    if (parts.Length == 0) continue;
    var command = parts[0].ToLowerInvariant();
    var argument = parts.Length == 2 ? parts[1].Trim() : "";
    if (combat is not null)
    {
        Console.WriteLine(combat.Act(command));
        if (combat.Ended) combat = null;
        continue;
    }
    switch (command)
    {
        case "help": Console.WriteLine("look, go <direction>, talk, quest, inventory, status, fight, buy potion, use potion, quit"); break;
        case "look": Console.WriteLine($"Location: {game.Location}. Exits: {string.Join(", ", game.AvailableExits)}"); break;
        case "go": Console.WriteLine(game.Move(argument) ? $"Arrived at {game.Location}." : "You cannot travel that way."); break;
        case "talk": Console.WriteLine(game.Talk()); break;
        case "quest": Console.WriteLine(game.QuestStatus); break;
        case "inventory": Console.WriteLine(game.Inventory.Count == 0 ? "Inventory is empty." : string.Join("\n", game.Inventory.Select(x => $"{x.Key}: {x.Value}"))); break;
        case "status": Console.WriteLine($"HP: {game.Health}/30 | Gold: {game.Gold}"); break;
        case "fight": combat = game.BeginCombat(); Console.WriteLine(combat is null ? "There are no enemies here." : $"A {combat.EnemyName} appears!"); break;
        case "buy": Console.WriteLine(argument.Equals("potion", StringComparison.OrdinalIgnoreCase) && game.BuyPotion() ? "Purchased 1 Potion." : "Cannot buy a potion here or insufficient gold."); break;
        case "use": Console.WriteLine(argument.Equals("potion", StringComparison.OrdinalIgnoreCase) && game.UsePotion() ? $"Potion used. HP: {game.Health}/30." : "No usable potion."); break;
        default: Console.WriteLine("Unknown command."); break;
    }
}
Console.WriteLine("Thanks for playing!");
