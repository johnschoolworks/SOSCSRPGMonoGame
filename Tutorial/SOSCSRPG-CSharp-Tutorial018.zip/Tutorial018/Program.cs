using System;
using System.Collections.Generic;
using System.Linq;

var game = new Game();
game.Run();

sealed class Location(string name, string description)
{
    public string Name { get; } = name;
    public string Description { get; } = description;
    public Dictionary<string, string> Exits { get; } = new(StringComparer.OrdinalIgnoreCase);
}

sealed class Quest
{
    public bool Accepted { get; set; }
    public bool Completed { get; set; }
    public int SilkRequired => 3;
}

sealed class Game
{
    private readonly Dictionary<string, Location> _world = new(StringComparer.OrdinalIgnoreCase);
    private readonly Dictionary<string, int> _inventory = new(StringComparer.OrdinalIgnoreCase);
    private readonly Quest _quest = new();
    private readonly Random _rng = new();
    private string _current = "town";
    private int _hp = 30;
    private int _gold;
    private bool _running = true;

    public Game()
    {
        Add("town", "Town Square", "A lively town and a safe place to rest.");
        Add("hut", "Alchemist Hut", "The alchemist studies remedies and strange creatures.");
        Add("forest", "Forest", "Wild creatures roam between the trees.");
        Add("cave", "Spider Cave", "Webs cover the walls. Spiders lurk in the shadows.");
        Add("post", "Trading Post", "A merchant sells healing potions.");
        Link("town", "west", "hut", "east");
        Link("town", "east", "forest", "west");
        Link("hut", "south", "post", "north");
        Link("forest", "south", "cave", "north");
        Link("hut", "east", "forest", "west");
    }

    private void Add(string id, string name, string description) => _world[id] = new(name, description);
    private void Link(string a, string directionA, string b, string directionB)
    {
        _world[a].Exits[directionA] = b;
        _world[b].Exits[directionB] = a;
    }

    public void Run()
    {
        Console.WriteLine("SOSCSRPG — Tutorial 018: World and Quest Integration");
        Console.WriteLine("Type 'help' to see commands.");
        Look();
        while (_running)
        {
            Console.Write("\n> ");
            var input = Console.ReadLine();
            if (input is null) break;
            var words = input.Trim().Split(' ', 2, StringSplitOptions.RemoveEmptyEntries);
            if (words.Length == 0) continue;
            var command = words[0].ToLowerInvariant();
            var argument = words.Length > 1 ? words[1].Trim() : "";
            switch (command)
            {
                case "help": Help(); break;
                case "look": Look(); break;
                case "go": Move(argument); break;
                case "talk": Talk(); break;
                case "quest": ShowQuest(); break;
                case "inventory": ShowInventory(); break;
                case "status": Console.WriteLine($"HP: {_hp}/30 | Gold: {_gold}"); break;
                case "fight": Fight(); break;
                case "buy": Buy(argument); break;
                case "use": Use(argument); break;
                case "quit": _running = false; break;
                default: Console.WriteLine("Unknown command. Type 'help'."); break;
            }
        }
        Console.WriteLine("Thanks for playing!");
    }

    private static void Help() => Console.WriteLine("Commands: look, go <north|south|east|west>, talk, quest, inventory, status, fight, buy potion, use potion, quit");

    private void Look()
    {
        var location = _world[_current];
        Console.WriteLine($"\n{location.Name}: {location.Description}");
        Console.WriteLine("Exits: " + string.Join(", ", location.Exits.Keys.OrderBy(x => x)));
        if (_current is "hut" or "post") Console.WriteLine("Someone is here. Try 'talk'.");
        if (_current is "forest" or "cave") Console.WriteLine("Dangerous creatures are nearby. Try 'fight'.");
    }

    private void Move(string direction)
    {
        if (!_world[_current].Exits.TryGetValue(direction, out var destination))
        {
            Console.WriteLine("You cannot travel that way.");
            return;
        }
        _current = destination;
        Look();
    }

    private void Talk()
    {
        if (_current == "hut")
        {
            if (_quest.Completed) Console.WriteLine("Alchemist: Thank you again for the silk!");
            else if (!_quest.Accepted)
            {
                _quest.Accepted = true;
                Console.WriteLine("Alchemist: Bring me 3 Spider Silk and I will reward you with 20 gold!");
            }
            else if (Count("Spider Silk") >= _quest.SilkRequired)
            {
                Remove("Spider Silk", _quest.SilkRequired);
                _gold += 20;
                _quest.Completed = true;
                Console.WriteLine("Quest complete! You received 20 gold.");
            }
            else Console.WriteLine($"Alchemist: You have {Count("Spider Silk")}/3 Spider Silk. Keep searching!");
        }
        else if (_current == "post") Console.WriteLine("Merchant: Healing potions cost 5 gold. Type 'buy potion'.");
        else Console.WriteLine("There is nobody here to talk to.");
    }

    private void ShowQuest()
    {
        if (_quest.Completed) Console.WriteLine("Spider Silk: Completed.");
        else if (_quest.Accepted) Console.WriteLine($"Spider Silk: {Count("Spider Silk")}/3 collected. Return to the Alchemist Hut.");
        else Console.WriteLine("No active quests. Visit the Alchemist Hut.");
    }

    private int Count(string item) => _inventory.GetValueOrDefault(item);
    private void AddItem(string item, int count) => _inventory[item] = Count(item) + count;
    private void Remove(string item, int count)
    {
        var remaining = Count(item) - count;
        if (remaining <= 0) _inventory.Remove(item);
        else _inventory[item] = remaining;
    }
    private void ShowInventory() => Console.WriteLine(_inventory.Count == 0 ? "Inventory is empty." : string.Join("\n", _inventory.Select(x => $"{x.Key}: {x.Value}")));

    private void Fight()
    {
        if (_current is not ("forest" or "cave"))
        {
            Console.WriteLine("There are no enemies here.");
            return;
        }
        var spider = _current == "cave";
        var enemyName = spider ? "Cave Spider" : "Forest Wolf";
        var enemyHp = spider ? 12 : 9;
        var defending = false;
        Console.WriteLine($"A {enemyName} appears! (attack / defend / potion / flee)");
        while (enemyHp > 0 && _hp > 0)
        {
            Console.Write($"[HP {_hp}/30 | Enemy {enemyHp}] action> ");
            var action = Console.ReadLine()?.Trim().ToLowerInvariant();
            if (action is null) { _running = false; return; }
            if (action == "flee") { Console.WriteLine("You escape!"); return; }
            if (action == "potion")
            {
                if (Count("Potion") == 0) { Console.WriteLine("No potions available."); continue; }
                Use("potion");
            }
            else if (action == "defend")
            {
                defending = true;
                Console.WriteLine("You brace for the next attack.");
            }
            else if (action == "attack")
            {
                if (_rng.Next(100) < 10) Console.WriteLine($"The {enemyName} dodges!");
                else
                {
                    var critical = _rng.Next(100) < 15;
                    var damage = _rng.Next(4, 8) * (critical ? 2 : 1);
                    enemyHp -= damage;
                    Console.WriteLine($"You deal {damage} damage{(critical ? " (CRITICAL!)" : "")}.");
                }
            }
            else { Console.WriteLine("Choose attack, defend, potion, or flee."); continue; }
            if (enemyHp <= 0) break;
            var incoming = _rng.Next(2, 6);
            if (defending) incoming = (incoming + 1) / 2;
            defending = false;
            _hp = Math.Max(0, _hp - incoming);
            Console.WriteLine($"The {enemyName} hits you for {incoming} damage.");
        }
        if (_hp == 0)
        {
            Console.WriteLine("You were defeated. You recover at Town Square with 30 HP.");
            _hp = 30;
            _current = "town";
            return;
        }
        Console.WriteLine($"You defeated the {enemyName}!");
        _gold += spider ? 3 : 2;
        if (spider)
        {
            AddItem("Spider Silk", 1); // Guaranteed quest drop
            Console.WriteLine("Loot: 1 Spider Silk (guaranteed), 3 gold.");
            if (_rng.Next(100) < 25) { AddItem("Potion", 1); Console.WriteLine("Bonus loot: 1 Potion!"); }
        }
        else Console.WriteLine("Loot: 2 gold.");
    }

    private void Buy(string item)
    {
        if (_current != "post" || !item.Equals("potion", StringComparison.OrdinalIgnoreCase))
        {
            Console.WriteLine("Visit the Trading Post and type 'buy potion'.");
            return;
        }
        if (_gold < 5) { Console.WriteLine("You need 5 gold."); return; }
        _gold -= 5;
        AddItem("Potion", 1);
        Console.WriteLine("Purchased 1 Potion.");
    }

    private void Use(string item)
    {
        if (!item.Equals("potion", StringComparison.OrdinalIgnoreCase) || Count("Potion") == 0)
        {
            Console.WriteLine("You do not have that usable item.");
            return;
        }
        Remove("Potion", 1);
        var oldHp = _hp;
        _hp = Math.Min(30, _hp + 12);
        Console.WriteLine($"Potion restored {_hp - oldHp} HP. HP: {_hp}/30.");
    }
}
